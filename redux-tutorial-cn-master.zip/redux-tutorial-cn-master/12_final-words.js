// 章节 12 - final-words.js

// 除了本教程，其实 Redux 和 react-redux 还有很多可以学习的。比如:
// 考虑到 Redux 的安全性，你可能会对 bindActionCreators 感兴趣（创建一个已绑定到 dispatch 的 action creators
// hash 对象 -http://rackt.org/redux/docs/api/bindActionCreators.html)。

// 希望我们已经给了你一些秘诀去更好的理解 Flux ，以及 Flux 不同实现之间的区别
// --当然包括 Redux 是如何脱颖而出的 ;)。

// 接下去呢?

// Redux 的官方文档真的非常出色和详尽，所以从现在开始不要再犹豫要不要看它了：
// http://rackt.org/redux/index.html

// 祝你和 React、Redux 玩的开心2333!
